﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tweet.DAL
{
    public class ChangePasswordModel
    {
        public string password { get; set; }
        public string newPassword { get; set; } 
    }
}
