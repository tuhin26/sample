﻿using MimeKit;
using System;
using System.Collections.Generic;
using System.Text;
using Tweet.ForgetPasswordService.Models;

namespace Tweet.ForgetPasswordService
{
  public  interface ISender
    {
        void SendEmail(EmailMessage message);
        MimeMessage CreateEmailMessage(EmailMessage message);
        void Send(MimeMessage mailMessage);
    }
}
